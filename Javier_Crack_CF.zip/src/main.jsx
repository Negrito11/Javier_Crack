import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { openDB } from 'idb';

async function initDB() {
  const db = await openDB('javier-crack-db', 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('keyval')) {
        db.createObjectStore('keyval');
      }
    },
  });
  return db;
}

initDB().then(() => {
    console.log("Database initialized");
});


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
