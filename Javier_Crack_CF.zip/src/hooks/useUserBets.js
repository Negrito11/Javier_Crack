
import { useState, useEffect, useCallback } from 'react';

const USER_BETS_STORAGE_KEY_PREFIX = 'tipster_user_bets_';

export function useUserBets(bank) {
  const [userBets, setUserBets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const loggedInUser = JSON.parse(localStorage.getItem('tipster_logged_in_user'));
  const USER_BETS_STORAGE_KEY = loggedInUser ? `${USER_BETS_STORAGE_KEY_PREFIX}${loggedInUser.id}` : null;


  useEffect(() => {
    if (!USER_BETS_STORAGE_KEY) {
        setIsLoading(false);
        return;
    };
    try {
      const savedUserBets = localStorage.getItem(USER_BETS_STORAGE_KEY);
      if (savedUserBets) {
        setUserBets(JSON.parse(savedUserBets));
      }
    } catch (error) {
      console.error("Failed to load user bets from localStorage", error);
    }
    setIsLoading(false);
  }, [USER_BETS_STORAGE_KEY]);

  const persistUserBets = useCallback((newBets) => {
      if (!USER_BETS_STORAGE_KEY) return;
      localStorage.setItem(USER_BETS_STORAGE_KEY, JSON.stringify(newBets));
      setUserBets(newBets);
  }, [USER_BETS_STORAGE_KEY]);

  const findUserBet = useCallback((tipsterBetId) => {
    return userBets.find(ub => ub.tipsterBetId === tipsterBetId);
  }, [userBets]);
  
  const placeUserBet = useCallback((tipsterBet, amount, odds) => {
    if (bank.balance < amount) {
      return { success: false, message: "Saldo insuficiente." };
    }

    const newUserBet = {
      id: `${tipsterBet.id}-${Date.now()}`,
      tipsterBetId: tipsterBet.id,
      amount: Number(amount),
      odds: Number(odds),
      status: 'pending',
      createdAt: new Date().toISOString(),
      event: tipsterBet.event,
    };
    
    bank.placeBet(amount);
    persistUserBets([...userBets, newUserBet]);
    return { success: true };
  }, [bank, userBets, persistUserBets]);

  const updateUserBetStatus = useCallback((tipsterBet) => {
    const userBet = findUserBet(tipsterBet.id);
    if (userBet && userBet.status === 'pending' && tipsterBet.status !== 'pending') {
      bank.resolveBet(userBet.amount, userBet.odds, tipsterBet.status);
      
      const newBets = userBets.map(ub => 
        ub.id === userBet.id ? { ...ub, status: tipsterBet.status } : ub
      );
      persistUserBets(newBets);
    }
  }, [findUserBet, bank, userBets, persistUserBets]);

  const getHistoricalUserBets = useCallback(() => {
    return userBets
      .filter(ub => ub.status !== 'pending')
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [userBets]);

  return {
    userBets,
    isLoading,
    findUserBet,
    placeUserBet,
    updateUserBetStatus,
    getHistoricalUserBets
  };
}
