
import { useState, useEffect } from 'react';

const USERS_STORAGE_KEY = 'tipster_users_db';

export function useUsers() {
    const [users, setUsers] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const savedUsers = localStorage.getItem(USERS_STORAGE_KEY);
        if (savedUsers) {
            setUsers(JSON.parse(savedUsers));
        }
        setIsLoading(false);
    }, []);

    const toggleUserStatus = (userId) => {
        const updatedUsers = users.map(user => {
            if (user.id === userId) {
                return { ...user, isEnabled: !user.isEnabled };
            }
            return user;
        });
        setUsers(updatedUsers);
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updatedUsers));
    };

    return { users, toggleUserStatus, isLoading };
}
