import { useState, useEffect, useCallback } from 'react';

const BANK_STORAGE_KEY = 'tipster_bank';

export function useBank() {
  const [balance, setBalance] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const savedBank = localStorage.getItem(BANK_STORAGE_KEY);
      if (savedBank) {
        setBalance(JSON.parse(savedBank).balance);
      } else {
        setBalance(1000); // Initial default balance
        localStorage.setItem(BANK_STORAGE_KEY, JSON.stringify({ balance: 1000 }));
      }
    } catch (error) {
      console.error("Failed to load bank from localStorage", error);
      setBalance(1000);
    }
    setIsLoading(false);
  }, []);

  const updateBalance = useCallback((newBalance) => {
    const numericBalance = Number(newBalance);
    if (!isNaN(numericBalance)) {
      setBalance(numericBalance);
      localStorage.setItem(BANK_STORAGE_KEY, JSON.stringify({ balance: numericBalance }));
    }
  }, []);

  const placeBet = useCallback((amount) => {
    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) return false;

    setBalance(prevBalance => {
      const newBalance = prevBalance - numericAmount;
      localStorage.setItem(BANK_STORAGE_KEY, JSON.stringify({ balance: newBalance }));
      return newBalance;
    });
    return true;
  }, []);

  const resolveBet = useCallback((amount, odds, result) => {
    const numericAmount = Number(amount);
    const numericOdds = Number(odds);
    if (isNaN(numericAmount) || isNaN(numericOdds)) return;

    setBalance(prevBalance => {
      let newBalance = prevBalance;
      if (result === 'win') {
        newBalance += numericAmount * numericOdds;
      } else if (result === 'null') {
        newBalance += numericAmount;
      }
      localStorage.setItem(BANK_STORAGE_KEY, JSON.stringify({ balance: newBalance }));
      return newBalance;
    });
  }, []);

  return { balance, updateBalance, placeBet, resolveBet, isLoading };
}