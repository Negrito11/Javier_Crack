
import { useState, useEffect, useCallback } from 'react';

// For simplicity, we'll manage a list of users in localStorage.
// In a real app, this would be a secure database.
const USERS_STORAGE_KEY = 'tipster_users_db';
const LOGGED_IN_USER_KEY = 'tipster_logged_in_user';

const getInitialUsers = () => {
    const savedUsers = localStorage.getItem(USERS_STORAGE_KEY);
    if (savedUsers) {
        return JSON.parse(savedUsers);
    }
    // Create a default admin user. In a real app, this would be done securely.
    const adminUser = {
        id: 'admin_001',
        firstName: 'Admin',
        lastName: 'Crack',
        email: 'admin@javiercrack.com',
        phone: '1234567890',
        password: 'password123', // WARNING: Storing plain text passwords is not secure. For demo purposes only.
        role: 'admin',
        isEnabled: true,
    };
    const initialUsers = [adminUser];
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(initialUsers));
    return initialUsers;
};

export function useAuth() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [users, setUsers] = useState(getInitialUsers);

  useEffect(() => {
    const savedUser = localStorage.getItem(LOGGED_IN_USER_KEY);
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const persistUsers = (newUsers) => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(newUsers));
    setUsers(newUsers);
  };

  const login = useCallback((identifier, password) => {
    const foundUser = users.find(
      u => (u.email === identifier || u.phone === identifier) && u.password === password
    );

    if (foundUser) {
      if (foundUser.role === 'client' && !foundUser.isEnabled) {
          return { success: false, message: 'Tu cuenta está deshabilitada. Contacta al administrador.' };
      }
      localStorage.setItem(LOGGED_IN_USER_KEY, JSON.stringify(foundUser));
      setUser(foundUser);
      return { success: true };
    }
    return { success: false, message: 'Credenciales incorrectas. Inténtalo de nuevo.' };
  }, [users]);
  
  const register = useCallback((userData) => {
    const userExists = users.some(
      u => (userData.email && u.email === userData.email) || (userData.phone && u.phone === userData.phone)
    );

    if (userExists) {
        return { success: false, message: 'Un usuario con este email o teléfono ya existe.' };
    }

    const newUser = {
        ...userData,
        id: `user_${Date.now()}`,
        role: 'client',
        isEnabled: true,
    };
    
    const newUsers = [...users, newUser];
    persistUsers(newUsers);

    localStorage.setItem(LOGGED_IN_USER_KEY, JSON.stringify(newUser));
    setUser(newUser);
    return { success: true };
  }, [users]);

  const updateUser = useCallback((userData) => {
    let loggedInUser = null;
    const updatedUsers = users.map(u => {
      if (u.id === user.id) {
        loggedInUser = { ...u, ...userData };
        return loggedInUser;
      }
      return u;
    });

    persistUsers(updatedUsers);
    if (loggedInUser) {
        localStorage.setItem(LOGGED_IN_USER_KEY, JSON.stringify(loggedInUser));
        setUser(loggedInUser);
    }
  }, [user, users]);

  const logout = useCallback(() => {
    localStorage.removeItem(LOGGED_IN_USER_KEY);
    setUser(null);
  }, []);

  return { user, login, register, updateUser, logout, isLoading };
}
