
import { useState, useEffect } from 'react';

const mockBetsData = [
  {
    id: '1',
    event: 'Real Madrid vs Barcelona',
    sport: 'Fútbol',
    league: 'La Liga',
    betType: 'Resultado Final',
    suggestion: 'Real Madrid Gana',
    odds: 2.15,
    suggestedAmount: 50,
    eventDate: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
    status: 'pending',
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    event: 'Lakers vs Warriors',
    sport: 'Baloncesto',
    league: 'NBA',
    betType: 'Puntos Totales',
    suggestion: 'Más de 220.5 puntos',
    odds: 1.85,
    suggestedAmount: 75,
    eventDate: new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString(),
    status: 'pending',
    createdAt: new Date().toISOString()
  },
  {
    id: '3',
    event: 'Manchester United vs Liverpool',
    sport: 'Fútbol',
    league: 'Premier League',
    betType: 'Ambos Equipos Anotan',
    suggestion: 'Sí',
    odds: 1.65,
    suggestedAmount: 100,
    eventDate: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    status: 'win',
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '4',
    event: 'PSG vs Bayern Munich',
    sport: 'Fútbol',
    league: 'Champions League',
    betType: 'Resultado Final',
    suggestion: 'Empate',
    odds: 3.20,
    suggestedAmount: 30,
    eventDate: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    status: 'lose',
    createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '5',
    event: 'Juventus vs AC Milan',
    sport: 'Fútbol',
    league: 'Serie A',
    betType: 'Goles Totales',
    suggestion: 'Menos de 2.5 goles',
    odds: 2.05,
    suggestedAmount: 60,
    eventDate: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    status: 'null',
    createdAt: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString()
  }
];

const BETS_STORAGE_KEY = 'tipster_bets';

export function useBets(onBetStatusChange) {
  const [bets, setBets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedBets = localStorage.getItem(BETS_STORAGE_KEY);
    const initialBets = savedBets ? JSON.parse(savedBets) : mockBetsData;
    setBets(initialBets);
    if (!savedBets) {
        localStorage.setItem(BETS_STORAGE_KEY, JSON.stringify(initialBets));
    }
    setIsLoading(false);
  }, []);
  
  const persistBets = (newBets) => {
    localStorage.setItem(BETS_STORAGE_KEY, JSON.stringify(newBets));
    setBets(newBets);
  };
  
  // Simulate tipster updating results after event
  useEffect(() => {
    const interval = setInterval(() => {
      let betsUpdated = false;
      const now = new Date();
      const updatedBets = bets.map(bet => {
        if (bet.status === 'pending' && new Date(bet.eventDate) < now) {
          betsUpdated = true;
          const outcomes = ['win', 'lose', 'null'];
          const newStatus = outcomes[Math.floor(Math.random() * outcomes.length)];
          const updatedBet = { ...bet, status: newStatus };
          if (onBetStatusChange) {
            onBetStatusChange(updatedBet);
          }
          return updatedBet;
        }
        return bet;
      });

      if (betsUpdated) {
        persistBets(updatedBets);
      }
    }, 10000); // Check every 10 seconds

    return () => clearInterval(interval);
  }, [bets, onBetStatusChange]);

  const addBet = (betData) => {
    const newBet = {
      ...betData,
      id: `bet_${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    persistBets([newBet, ...bets]);
  };

  const getActiveBets = () => {
    return bets.filter(bet => bet.status === 'pending');
  };

  const getHistoricalBets = () => {
    return bets
      .filter(bet => bet.status !== 'pending')
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  };

  const getStats = () => {
    const historicalBets = getHistoricalBets();
    const wins = historicalBets.filter(bet => bet.status === 'win').length;
    const losses = historicalBets.filter(bet => bet.status === 'lose').length;
    const nulls = historicalBets.filter(bet => bet.status === 'null').length;
    const total = historicalBets.length;
    
    return {
      total,
      wins,
      losses,
      nulls,
      winRate: total > 0 && (total - nulls > 0) ? ((wins / (total - nulls)) * 100).toFixed(1) : '0.0'
    };
  };

  return {
    bets,
    addBet,
    getActiveBets,
    getHistoricalBets,
    getStats,
    isLoading
  };
}
