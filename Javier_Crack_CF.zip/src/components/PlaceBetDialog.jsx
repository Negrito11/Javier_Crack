
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { DollarSign, BarChart2, Paperclip } from 'lucide-react';

export function PlaceBetDialog({ open, onOpenChange, bet, onPlaceBet }) {
  const [amount, setAmount] = useState('');
  const [odds, setOdds] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (bet) {
      setOdds(bet.odds);
      setAmount(bet.suggestedAmount || '');
    }
  }, [bet]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const numericAmount = Number(amount);
    const numericOdds = Number(odds);

    if (isNaN(numericAmount) || numericAmount <= 0) {
      toast({ title: "Monto inválido", description: "El monto debe ser un número positivo.", variant: "destructive" });
      return;
    }
    if (isNaN(numericOdds) || numericOdds <= 1) {
      toast({ title: "Momio inválido", description: "El momio debe ser mayor a 1.", variant: "destructive" });
      return;
    }
    
    const result = onPlaceBet(bet, numericAmount, numericOdds);
    
    if (result.success) {
      onOpenChange(false);
      toast({
        title: "¡Apuesta Realizada!",
        description: `Apostaste $${numericAmount.toFixed(2)} a ${bet.suggestion}.`
      });
      setAmount('');
    } else {
      toast({ title: "Error al apostar", description: result.message, variant: "destructive" });
    }
  };

  if (!bet) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-blue-base border-blue-primary/50 text-text-light max-w-md">
        <DialogHeader>
           <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-primary to-blue-primary/80 rounded-full flex items-center justify-center">
              <Paperclip className="w-5 h-5 text-text-light" />
            </div>
            <div>
              <DialogTitle className="text-xl">Realizar Apuesta</DialogTitle>
              <DialogDescription className="text-gray-400">{bet.event}</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="text-center my-4 p-3 rounded-lg bg-text-light/10">
          <p className="text-sm text-gray-300">Sugerencia</p>
          <p className="font-bold text-lg text-highlight-green">{bet.suggestion}</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Monto a Apostar</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="bg-blue-base/50 border-blue-primary/30 text-text-light pl-10"
                  placeholder="50.00"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="odds">Momio</Label>
              <div className="relative">
                <BarChart2 className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="odds"
                  type="number"
                  step="0.01"
                  value={odds}
                  onChange={(e) => setOdds(e.target.value)}
                  className="bg-blue-base/50 border-blue-primary/30 text-text-light pl-10"
                  placeholder="2.15"
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button 
              type="submit"
              className="w-full bg-gradient-to-r from-blue-primary to-blue-primary/80 hover:from-blue-primary/90 hover:to-blue-primary text-text-light font-semibold"
            >
              Confirmar Apuesta
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
