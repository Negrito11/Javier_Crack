import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { User, Mail, Phone, Lock, Eye, EyeOff } from 'lucide-react';

export function LoginForm({ onLogin }) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();

  const validatePassword = (password) => {
    const passwordRegex = /^[a-zA-Z0-9._!-]{6,}$/;
    return passwordRegex.test(password);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.firstName || !formData.lastName || (!formData.email && !formData.phone)) {
      toast({
        title: "Error de validación",
        description: "Por favor completa todos los campos requeridos.",
        variant: "destructive"
      });
      return;
    }

    if (!validatePassword(formData.password)) {
      toast({
        title: "Contraseña no válida",
        description: "La contraseña debe tener al menos 6 caracteres y solo puede contener letras, números y los símbolos '._-!'.",
        variant: "destructive"
      });
      return;
    }

    onLogin(formData);
    toast({
      title: "¡Bienvenido!",
      description: "Te has registrado exitosamente en TipsterPro."
    });
  };

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-blue-base">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light">
          <CardHeader className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="mx-auto mb-4 w-16 h-16 bg-gradient-to-r from-blue-primary to-blue-primary/80 rounded-full flex items-center justify-center"
            >
              <User className="w-8 h-8 text-text-light" />
            </motion.div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-primary to-blue-primary/80 bg-clip-text text-transparent">
              TipsterPro
            </CardTitle>
            <CardDescription className="text-gray-300">
              Únete a la comunidad de apuestas más exitosa
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">Nombre *</Label>
                  <Input
                    id="firstName"
                    name="firstName"
                    type="text"
                    value={formData.firstName}
                    onChange={handleChange}
                    className="bg-text-light/10 border-text-light/20 text-text-light placeholder:text-gray-400"
                    placeholder="Tu nombre"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Apellido *</Label>
                  <Input
                    id="lastName"
                    name="lastName"
                    type="text"
                    value={formData.lastName}
                    onChange={handleChange}
                    className="bg-text-light/10 border-text-light/20 text-text-light placeholder:text-gray-400"
                    placeholder="Tu apellido"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="bg-text-light/10 border-text-light/20 text-text-light placeholder:text-gray-400 pl-10"
                    placeholder="tu@email.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    className="bg-text-light/10 border-text-light/20 text-text-light placeholder:text-gray-400 pl-10"
                    placeholder="+1 234 567 8900"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Contraseña *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={handleChange}
                    className="bg-text-light/10 border-text-light/20 text-text-light placeholder:text-gray-400 pl-10"
                    placeholder="Mínimo 6 caracteres"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-text-light"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <p className="text-xs text-gray-400">
                * Campos requeridos. Debes proporcionar al menos email o teléfono.
              </p>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-blue-primary to-blue-primary/80 hover:from-blue-primary/90 hover:to-blue-primary text-text-light font-semibold py-2 px-4 rounded-lg transition-all duration-200 transform hover:scale-105"
              >
                Comenzar a Apostar
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}