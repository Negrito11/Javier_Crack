import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Landmark, Save } from 'lucide-react';

export function BankDialog({ open, onOpenChange, balance, onUpdateBalance }) {
  const [amount, setAmount] = useState(balance);
  const { toast } = useToast();

  useEffect(() => {
    setAmount(balance);
  }, [balance]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount < 0) {
      toast({
        title: "Cantidad no válida",
        description: "Por favor, introduce un número positivo.",
        variant: "destructive"
      });
      return;
    }
    onUpdateBalance(numericAmount);
    onOpenChange(false);
    toast({
      title: "¡Banco Actualizado!",
      description: `Tu nuevo saldo es $${numericAmount.toFixed(2)}.`
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-blue-base border-blue-primary/50 text-text-light max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 bg-gradient-to-r from-highlight-green to-highlight-green/80 rounded-full flex items-center justify-center">
              <Landmark className="w-5 h-5 text-text-dark" />
            </div>
            <div>
              <DialogTitle className="text-xl">Gestionar mi Banco</DialogTitle>
              <DialogDescription className="text-gray-400">
                Establece tu saldo inicial para simular apuestas.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="balance">Saldo Actual</Label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 h-4 w-4 text-gray-400">$</span>
              <Input
                id="balance"
                name="balance"
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-blue-base/50 border-blue-primary/30 text-text-light pl-8"
                placeholder="1000.00"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="bg-blue-base/50 border-blue-primary/30 text-text-light hover:bg-blue-base/70"
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              className="bg-gradient-to-r from-highlight-green to-highlight-green/80 hover:from-highlight-green/90 hover:to-highlight-green"
            >
              <Save className="w-4 h-4 mr-2" />
              Guardar Saldo
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}