
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { PlusCircle, Save } from 'lucide-react';

export function AddBetDialog({ open, onOpenChange, onAddBet }) {
  const [formData, setFormData] = useState({
    event: '',
    sport: '',
    league: '',
    betType: '',
    suggestion: '',
    odds: '',
    suggestedAmount: '',
    eventDate: ''
  });
  const { toast } = useToast();

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation
    for (const key in formData) {
      if (!formData[key]) {
        toast({
          title: "Campos incompletos",
          description: "Por favor, rellena todos los campos para añadir la sugerencia.",
          variant: "destructive",
        });
        return;
      }
    }

    onAddBet({
      ...formData,
      odds: parseFloat(formData.odds),
      suggestedAmount: parseFloat(formData.suggestedAmount),
      eventDate: new Date(formData.eventDate).toISOString(),
    });
    
    toast({
        title: "Sugerencia Añadida",
        description: "La nueva sugerencia de apuesta ha sido creada.",
    });

    // Reset form and close dialog
    setFormData({ event: '', sport: '', league: '', betType: '', suggestion: '', odds: '', suggestedAmount: '', eventDate: '' });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-blue-base border-blue-primary/50 text-text-light sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-primary to-blue-primary/80 rounded-full flex items-center justify-center">
              <PlusCircle className="w-5 h-5 text-text-light" />
            </div>
            <div>
              <DialogTitle className="text-xl">Añadir Nueva Sugerencia</DialogTitle>
              <DialogDescription className="text-gray-400">
                Crea una nueva sugerencia de apuesta para los clientes.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="event">Evento</Label>
            <Input id="event" name="event" value={formData.event} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: Real Madrid vs Barcelona" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sport">Deporte</Label>
            <Input id="sport" name="sport" value={formData.sport} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: Fútbol" />
          </div>
           <div className="space-y-2">
            <Label htmlFor="league">Liga</Label>
            <Input id="league" name="league" value={formData.league} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: La Liga" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="betType">Tipo de Apuesta</Label>
            <Input id="betType" name="betType" value={formData.betType} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: Resultado Final" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="suggestion">Sugerencia</Label>
            <Input id="suggestion" name="suggestion" value={formData.suggestion} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: Real Madrid Gana" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="odds">Momio</Label>
            <Input id="odds" name="odds" type="number" step="0.01" value={formData.odds} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: 2.15" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="suggestedAmount">Monto Sugerido ($)</Label>
            <Input id="suggestedAmount" name="suggestedAmount" type="number" step="1" value={formData.suggestedAmount} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" placeholder="Ej: 50" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="eventDate">Fecha del Evento</Label>
            <Input id="eventDate" name="eventDate" type="datetime-local" value={formData.eventDate} onChange={handleChange} className="bg-blue-base/50 border-blue-primary/30" />
          </div>
          <DialogFooter className="sm:col-span-2 mt-4">
            <Button type="submit" className="w-full bg-gradient-to-r from-blue-primary to-blue-primary/80">
              <Save className="w-4 h-4 mr-2" />
              Guardar Sugerencia
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
