
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { User, Mail, Phone, Lock, Eye, EyeOff, LogIn, UserPlus } from 'lucide-react';

export function AuthForm({ onLogin, onRegister }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    identifier: '', // For login (email or phone)
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();

  const validatePassword = (password) => {
    const passwordRegex = /^[a-zA-Z0-9._!-]{6,}$/;
    return passwordRegex.test(password);
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    if (!formData.identifier || !formData.password) {
      toast({ title: "Campos requeridos", description: "Por favor, introduce tu identificador y contraseña.", variant: "destructive" });
      return;
    }
    const result = onLogin(formData.identifier, formData.password);
    if (!result.success) {
      toast({ title: "Error de acceso", description: result.message, variant: "destructive" });
    }
  };

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    if (!formData.firstName || !formData.lastName || (!formData.email && !formData.phone)) {
      toast({ title: "Error de validación", description: "Por favor completa Nombre, Apellido y Email o Teléfono.", variant: "destructive" });
      return;
    }
    if (!validatePassword(formData.password)) {
      toast({ title: "Contraseña no válida", description: "La contraseña debe tener al menos 6 caracteres y solo puede contener letras, números y los símbolos '._-!'.", variant: "destructive" });
      return;
    }
    const { identifier, ...registerData } = formData;
    const result = onRegister(registerData);

    if (result.success) {
      toast({ title: "¡Bienvenido!", description: "Te has registrado exitosamente en Javier_Crack." });
    } else {
      toast({ title: "Error de registro", description: result.message, variant: "destructive" });
    }
  };

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const toggleForm = () => {
    setIsLogin(!isLogin);
    setFormData({ identifier: '', firstName: '', lastName: '', email: '', phone: '', password: '' });
  };
  
  const formIcon = (
    <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring" }}
        className="mx-auto mb-4 w-20 h-20"
      >
        <img-replace src="/logo.png" alt="Logo de Javier_Crack, un conejo con máscara" className="w-full h-full" />
    </motion.div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-blue-base">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light">
          <CardHeader className="text-center">
            {formIcon}
            <CardTitle className="text-3xl font-bold text-text-light">
              Javier_Crack
            </CardTitle>
            <CardDescription className="text-gray-300">
              {isLogin ? "Inicia sesión para continuar" : "Únete a la comunidad de apuestas"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLogin ? (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="identifier">Email o Teléfono</Label>
                  <Input id="identifier" name="identifier" value={formData.identifier} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light" placeholder="tu@email.com o +123456789" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                   <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="password" name="password" type={showPassword ? 'text' : 'password'} value={formData.password} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light pl-10" required />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-text-light">
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-blue-primary to-blue-primary/80"><LogIn className="mr-2 h-4 w-4" /> Iniciar Sesión</Button>
              </form>
            ) : (
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Nombre *</Label>
                    <Input id="firstName" name="firstName" value={formData.firstName} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Apellido *</Label>
                    <Input id="lastName" name="lastName" value={formData.lastName} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña *</Label>
                   <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="password" name="password" type={showPassword ? 'text' : 'password'} value={formData.password} onChange={handleChange} className="bg-text-light/10 border-text-light/20 text-text-light pl-10" required />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-text-light">
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                 <p className="text-xs text-gray-400">* Campos requeridos. Debes proporcionar al menos email o teléfono.</p>
                <Button type="submit" className="w-full bg-gradient-to-r from-highlight-green to-highlight-green/80"><UserPlus className="mr-2 h-4 w-4" /> Registrarse</Button>
              </form>
            )}
            <div className="mt-4 text-center">
              <Button variant="link" onClick={toggleForm} className="text-blue-primary">
                {isLogin ? "¿No tienes cuenta? Regístrate" : "¿Ya tienes cuenta? Inicia Sesión"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
