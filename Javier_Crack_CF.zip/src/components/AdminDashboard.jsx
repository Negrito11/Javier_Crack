import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useBets } from '@/hooks/useBets';
import { useUsers } from '@/hooks/useUsers';
import { useToast } from '@/components/ui/use-toast';
import { LogOut, Users, BarChart3, PlusCircle, Check, X } from 'lucide-react';
import { AddBetDialog } from './AddBetDialog';
import { sendNotification } from '@/lib/notifications';

export function AdminDashboard({ admin, onLogout }) {
  const { addBet, getActiveBets, getHistoricalBets, isLoading: betsLoading } = useBets();
  const { users, toggleUserStatus, isLoading: usersLoading } = useUsers();
  const [activeTab, setActiveTab] = useState('bets');
  const [showAddBet, setShowAddBet] = useState(false);
  const { toast } = useToast();

  const isLoading = betsLoading || usersLoading;

  const handleToggleUser = (userId, isEnabled) => {
    toggleUserStatus(userId);
    toast({
      title: `Usuario ${isEnabled ? 'Deshabilitado' : 'Habilitado'}`,
      description: `El estado del cliente ha sido actualizado.`,
    });
  };

  const handleAddBet = (betData) => {
    addBet(betData);
    sendNotification({
      title: "🔥 ¡Nueva Sugerencia de Apuesta!",
      body: `No te pierdas: ${betData.suggestion} en ${betData.event}`
    });
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'win': return <Badge variant="win">GANADA</Badge>;
      case 'lose': return <Badge variant="lose">PERDIDA</Badge>;
      case 'null': return <Badge variant="null">NULA</Badge>;
      default: return <Badge variant="pending">VIGENTE</Badge>;
    }
  };

  const formatDate = (dateString) => new Date(dateString).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-blue-base">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-primary"></div>
      </div>
    );
  }

  const clientUsers = users.filter(u => u.role === 'client');
  const activeBets = getActiveBets();
  const historicalBets = getHistoricalBets();

  return (
    <>
      <Helmet>
        <title>Admin - Javier_Crack</title>
        <meta name="description" content="Panel de administración para Javier_Crack." />
      </Helmet>
      <div className="min-h-screen bg-blue-base p-4 overflow-x-hidden">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h1 className="text-3xl font-bold text-text-light">Panel de Administrador</h1>
              <p className="text-gray-300">Bienvenido, {admin.firstName}.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button onClick={() => setShowAddBet(true)} className="bg-gradient-to-r from-blue-primary to-blue-primary/80"><PlusCircle className="w-4 h-4 mr-2" />Nueva Sugerencia</Button>
              <Button onClick={onLogout} variant="outline" className="bg-red-500/20 border-red-500/30 text-red-300 hover:bg-red-500/30"><LogOut className="w-4 h-4 mr-2" />Salir</Button>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-6">
            <div className="flex space-x-1 bg-text-light/10 backdrop-blur-lg rounded-lg p-1">
              <Button onClick={() => setActiveTab('bets')} variant={activeTab === 'bets' ? 'default' : 'ghost'} className={`flex-1 ${activeTab === 'bets' ? 'bg-blue-primary text-text-light' : 'text-gray-300 hover:text-text-light hover:bg-text-light/10'}`}><BarChart3 className="w-4 h-4 mr-2" />Gestionar Apuestas</Button>
              <Button onClick={() => setActiveTab('clients')} variant={activeTab === 'clients' ? 'default' : 'ghost'} className={`flex-1 ${activeTab === 'clients' ? 'bg-blue-primary text-text-light' : 'text-gray-300 hover:text-text-light hover:bg-text-light/10'}`}><Users className="w-4 h-4 mr-2" />Gestionar Clientes ({clientUsers.length})</Button>
            </div>
          </motion.div>

          {activeTab === 'bets' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div>
                <h2 className="text-2xl font-semibold text-text-light mb-4">Sugerencias Vigentes</h2>
                <div className="space-y-4">
                  {activeBets.map(bet => (
                    <Card key={bet.id} className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light">
                      <CardHeader><CardTitle className="text-blue-primary">{bet.event}</CardTitle><CardDescription>{bet.sport} - {bet.league}</CardDescription></CardHeader>
                      <CardContent>
                        <p><strong>Sugerencia:</strong> <span className="text-highlight-green">{bet.suggestion}</span> @ {bet.odds}</p>
                        <p className="text-sm text-gray-400">Fecha: {formatDate(bet.eventDate)}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
               <div>
                <h2 className="text-2xl font-semibold text-text-light mb-4">Historial de Sugerencias</h2>
                <div className="space-y-4">
                  {historicalBets.map(bet => (
                    <Card key={bet.id} className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light">
                      <CardHeader className="flex flex-row justify-between items-center"><CardTitle>{bet.event}</CardTitle>{getStatusBadge(bet.status)}</CardHeader>
                      <CardContent>
                        <p><strong>Sugerencia:</strong> {bet.suggestion} @ {bet.odds}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'clients' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <h2 className="text-2xl font-semibold text-text-light mb-4">Clientes Registrados</h2>
              <div className="bg-text-light/10 backdrop-blur-lg border-text-light/20 rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                    <thead className="bg-text-light/10">
                        <tr>
                        <th className="p-4 font-semibold">Nombre</th>
                        <th className="p-4 font-semibold hidden sm:table-cell">Email</th>
                        <th className="p-4 font-semibold hidden md:table-cell">Teléfono</th>
                        <th className="p-4 font-semibold">Estado</th>
                        <th className="p-4 font-semibold text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {clientUsers.map(client => (
                        <tr key={client.id} className="border-b border-text-light/10">
                            <td className="p-4">{client.firstName} {client.lastName}</td>
                            <td className="p-4 hidden sm:table-cell">{client.email || 'N/A'}</td>
                            <td className="p-4 hidden md:table-cell">{client.phone || 'N/A'}</td>
                            <td className="p-4">
                            <Badge variant={client.isEnabled ? 'win' : 'destructive'}>
                                {client.isEnabled ? 'Activo' : 'Inactivo'}
                            </Badge>
                            </td>
                            <td className="p-4 text-right">
                            <Button onClick={() => handleToggleUser(client.id, client.isEnabled)} variant="ghost" size="icon" className={client.isEnabled ? 'text-red-400 hover:bg-red-500/20' : 'text-highlight-green hover:bg-highlight-green/20'}>
                                {client.isEnabled ? <X className="h-4 w-4" /> : <Check className="h-4 w-4" />}
                            </Button>
                            </td>
                        </tr>
                        ))}
                    </tbody>
                    </table>
                </div>
              </div>
            </motion.div>
          )}

        </div>
        <AddBetDialog open={showAddBet} onOpenChange={setShowAddBet} onAddBet={handleAddBet} />
      </div>
    </>
  );
}