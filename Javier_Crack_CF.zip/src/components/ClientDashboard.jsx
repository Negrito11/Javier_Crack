import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useBets } from '@/hooks/useBets';
import { useBank } from '@/hooks/useBank';
import { useUserBets } from '@/hooks/useUserBets';
import { ProfileDialog } from '@/components/ProfileDialog';
import { BankDialog } from '@/components/BankDialog';
import { PlaceBetDialog } from '@/components/PlaceBetDialog';
import { useToast } from '@/components/ui/use-toast';
import { 
  TrendingUp, Clock, History, User, Trophy, Target, Calendar,
  BarChart3, LogOut, Landmark, CheckCircle, CalendarDays, BarChartHorizontal, Bell, BellOff
} from 'lucide-react';
import { getWeek, getMonth, getYear } from 'date-fns';
import { requestNotificationPermission, getNotificationSubscription, subscribeUserToPush } from '@/lib/notifications';

export function ClientDashboard({ client, onUpdateUser, onLogout }) {
  const bank = useBank();
  const { updateUserBetStatus, findUserBet, placeUserBet, getHistoricalUserBets } = useUserBets(bank);
  const { getActiveBets, getStats, isLoading: betsLoading } = useBets(updateUserBetStatus);
  const [activeTab, setActiveTab] = useState('active');
  const [showProfile, setShowProfile] = useState(false);
  const [showBank, setShowBank] = useState(false);
  const [showPlaceBet, setShowPlaceBet] = useState(false);
  const [selectedBet, setSelectedBet] = useState(null);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const checkSubscription = async () => {
      const subscription = await getNotificationSubscription();
      setIsSubscribed(!!subscription);
    };
    checkSubscription();
  }, []);

  const handleNotificationToggle = async () => {
    if (isSubscribed) {
        toast({ title: "Función no implementada", description: "La anulación de suscripción aún no está disponible." });
    } else {
        try {
            await requestNotificationPermission();
            await subscribeUserToPush();
            setIsSubscribed(true);
            toast({ title: "¡Suscrito!", description: "Recibirás notificaciones de nuevas apuestas." });
        } catch (error) {
            toast({ title: "Error de Notificación", description: `No se pudieron activar las notificaciones: ${error.message}`, variant: "destructive" });
        }
    }
  };

  const activeBets = getActiveBets();
  const userHistoricalBets = getHistoricalUserBets();
  const stats = getStats();

  const handlePlaceBetClick = (bet) => {
    if (!client.isEnabled) {
        toast({
            title: "Cuenta Deshabilitada",
            description: "Tu cuenta está actualmente deshabilitada. Contacta al administrador.",
            variant: "destructive",
        });
        return;
    }
    setSelectedBet(bet);
    setShowPlaceBet(true);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'win': return <Badge variant="win">GANADA</Badge>;
      case 'lose': return <Badge variant="lose">PERDIDA</Badge>;
      case 'null': return <Badge variant="null">NULA</Badge>;
      default: return <Badge variant="pending">VIGENTE</Badge>;
    }
  };
  
  const formatDate = (dateString) => new Date(dateString).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  const historicalSummary = useMemo(() => {
    const weekly = {};
    const monthly = {};

    userHistoricalBets.forEach(bet => {
        const profit = bet.status === 'win' ? bet.amount * bet.odds - bet.amount : (bet.status === 'lose' ? -bet.amount : 0);
        const date = new Date(bet.createdAt);
        const year = getYear(date);
        const week = getWeek(date);
        const month = getMonth(date);

        const weeklyKey = `${year}-W${week}`;
        const monthlyKey = `${year}-M${month + 1}`;

        if (!weekly[weeklyKey]) weekly[weeklyKey] = 0;
        weekly[weeklyKey] += profit;

        if (!monthly[monthlyKey]) monthly[monthlyKey] = 0;
        monthly[monthlyKey] += profit;
    });

    return { weekly, monthly };
  }, [userHistoricalBets]);

  const isLoading = betsLoading || bank.isLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-blue-base">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-primary"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - Javier_Crack</title>
        <meta name="description" content="Tu dashboard personal de apuestas deportivas con seguimiento en tiempo real." />
      </Helmet>

      <div className="min-h-screen bg-blue-base p-4 overflow-x-hidden">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h1 className="text-3xl font-bold text-text-light">¡Hola, {client.firstName}! 👋</h1>
              <p className="text-gray-300">Bienvenido a tu dashboard de apuestas.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
                <Card className="bg-gradient-to-r from-highlight-green/20 to-highlight-green/10 border-highlight-green/30 text-text-light p-2 text-center flex-shrink-0">
                    <CardTitle className="text-sm font-medium flex items-center gap-2"><Landmark className="h-4 w-4 text-highlight-green" /> Banco</CardTitle>
                    <p className="text-xl font-bold text-highlight-green">${bank.balance?.toFixed(2)}</p>
                </Card>
                <div className="flex flex-wrap gap-2 flex-grow sm:flex-grow-0">
                    <Button onClick={handleNotificationToggle} variant="outline" className={`${isSubscribed ? 'bg-highlight-green/20 text-highlight-green border-highlight-green/30' : 'bg-blue-primary/10 border-blue-primary/20 text-text-light'} hover:bg-blue-primary/20`}>
                      {isSubscribed ? <BellOff className="w-4 h-4 mr-2"/> : <Bell className="w-4 h-4 mr-2" />}
                      {isSubscribed ? 'Notificaciones ON' : 'Activar Notificaciones'}
                    </Button>
                    <Button onClick={() => setShowBank(true)} variant="outline" className="bg-blue-primary/10 border-blue-primary/20 text-text-light hover:bg-blue-primary/20"><Landmark className="w-4 h-4 mr-2" />Banco</Button>
                    <Button onClick={() => setShowProfile(true)} variant="outline" className="bg-blue-primary/10 border-blue-primary/20 text-text-light hover:bg-blue-primary/20"><User className="w-4 h-4 mr-2" />Perfil</Button>
                    <Button onClick={onLogout} variant="outline" className="bg-red-500/20 border-red-500/30 text-red-300 hover:bg-red-500/30"><LogOut className="w-4 h-4 mr-2" />Salir</Button>
                </div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
             <Card className="bg-gradient-to-r from-highlight-green/20 to-highlight-green/10 border-highlight-green/30 text-text-light">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Ganadas (Tipster)</CardTitle><Trophy className="h-4 w-4 text-highlight-green" /></CardHeader>
              <CardContent><div className="text-2xl font-bold text-highlight-green">{stats.wins}</div></CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-red-500/20 to-rose-500/20 border-red-500/30 text-text-light">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Perdidas (Tipster)</CardTitle><Target className="h-4 w-4 text-red-400" /></CardHeader>
              <CardContent><div className="text-2xl font-bold text-red-400">{stats.losses}</div></CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-blue-primary/20 to-blue-primary/10 border-blue-primary/30 text-text-light">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Tasa Éxito</CardTitle><BarChart3 className="h-4 w-4 text-blue-primary" /></CardHeader>
              <CardContent><div className="text-2xl font-bold text-blue-primary">{stats.winRate}%</div></CardContent>
            </Card>
            <Card className="bg-gradient-to-r from-blue-primary/20 to-blue-primary/10 border-blue-primary/30 text-text-light">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Total Sugerencias</CardTitle><TrendingUp className="h-4 w-4 text-blue-primary" /></CardHeader>
              <CardContent><div className="text-2xl font-bold text-blue-primary">{stats.total}</div></CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-6">
            <div className="flex space-x-1 bg-text-light/10 backdrop-blur-lg rounded-lg p-1">
              <Button onClick={() => setActiveTab('active')} variant={activeTab === 'active' ? 'default' : 'ghost'} className={`flex-1 ${activeTab === 'active' ? 'bg-blue-primary text-text-light' : 'text-gray-300 hover:text-text-light hover:bg-text-light/10'}`}><Clock className="w-4 h-4 mr-2" />Sugerencias ({activeBets.length})</Button>
              <Button onClick={() => setActiveTab('history')} variant={activeTab === 'history' ? 'default' : 'ghost'} className={`flex-1 ${activeTab === 'history' ? 'bg-blue-primary text-text-light' : 'text-gray-300 hover:text-text-light hover:bg-text-light/10'}`}><History className="w-4 h-4 mr-2" />Mi Historial</Button>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            {activeTab === 'active' ? (
              <div className="space-y-4">
                {activeBets.length === 0 ? (
                  <Card className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light"><CardContent className="flex flex-col items-center justify-center py-12"><Clock className="w-16 h-16 text-gray-400 mb-4" /><h3 className="text-xl font-semibold mb-2">No hay sugerencias vigentes</h3><p className="text-gray-400 text-center">Vuelve más tarde para ver nuevas apuestas.</p></CardContent></Card>
                ) : (
                  activeBets.map((bet) => {
                    const userBet = findUserBet(bet.id);
                    return (
                    <motion.div key={bet.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} whileHover={{ scale: 1.02 }} transition={{ type: "spring", stiffness: 300 }}>
                      <Card className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light hover:bg-text-light/15 transition-all duration-200">
                        <CardHeader>
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center w-full gap-2">
                            <div><CardTitle className="text-lg text-blue-primary">{bet.event}</CardTitle><CardDescription className="text-gray-300">{bet.sport} • {bet.league}</CardDescription></div>
                            {getStatusBadge(bet.status)}
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                            <div><p className="text-sm text-gray-400 mb-1">Tipo</p><p className="font-semibold">{bet.betType}</p></div>
                            <div><p className="text-sm text-gray-400 mb-1">Sugerencia</p><p className="font-semibold text-highlight-green">{bet.suggestion}</p></div>
                            <div><p className="text-sm text-gray-400 mb-1">Momio Sugerido</p><p className="font-semibold text-yellow-400">{bet.odds}</p></div>
                          </div>
                          <div className="flex flex-col sm:flex-row justify-between items-center mt-4 pt-4 border-t border-text-light/10 gap-4">
                             <div className="flex items-center text-sm text-gray-400 text-center sm:text-left w-full sm:w-auto"><Calendar className="w-4 h-4 mr-1" />{formatDate(bet.eventDate)}</div>
                             {userBet ? (
                                <div className="flex items-center gap-2 text-highlight-green font-semibold p-2 rounded-md bg-highlight-green/10 text-center w-full sm:w-auto justify-center"><CheckCircle className="w-5 h-5" /> Apostado: ${userBet.amount.toFixed(2)} @ {userBet.odds.toFixed(2)}</div>
                             ) : (
                                <Button onClick={() => handlePlaceBetClick(bet)} className="w-full sm:w-auto bg-gradient-to-r from-blue-primary to-blue-primary/80 hover:from-blue-primary/90 hover:to-blue-primary">Apostar Ahora</Button>
                             )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )})
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card className="bg-text-light/10 border-text-light/20 text-text-light">
                    <CardHeader><CardTitle className="flex items-center gap-2"><CalendarDays className="text-blue-primary"/>Resumen Semanal</CardTitle></CardHeader>
                    <CardContent>
                      {Object.entries(historicalSummary.weekly).map(([week, profit]) => (
                        <div key={week} className="flex justify-between items-center mb-1">
                          <p>Semana {week.split('-W')[1]}</p>
                          <p className={`font-bold ${profit >= 0 ? 'text-highlight-green' : 'text-red-400'}`}>{profit >= 0 ? `+$${profit.toFixed(2)}` : `-$${Math.abs(profit).toFixed(2)}`}</p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                  <Card className="bg-text-light/10 border-text-light/20 text-text-light">
                    <CardHeader><CardTitle className="flex items-center gap-2"><BarChartHorizontal className="text-blue-primary"/>Resumen Mensual</CardTitle></CardHeader>
                    <CardContent>
                      {Object.entries(historicalSummary.monthly).map(([month, profit]) => (
                        <div key={month} className="flex justify-between items-center mb-1">
                          <p>Mes {month.split('-M')[1]}</p>
                          <p className={`font-bold ${profit >= 0 ? 'text-highlight-green' : 'text-red-400'}`}>{profit >= 0 ? `+$${profit.toFixed(2)}` : `-$${Math.abs(profit).toFixed(2)}`}</p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
                {userHistoricalBets.length === 0 ? (
                  <Card className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light"><CardContent className="flex flex-col items-center justify-center py-12"><History className="w-16 h-16 text-gray-400 mb-4" /><h3 className="text-xl font-semibold mb-2">Sin historial de apuestas</h3><p className="text-gray-400 text-center">Tus apuestas completadas aparecerán aquí.</p></CardContent></Card>
                ) : (
                  userHistoricalBets.map((bet) => {
                    const profit = bet.status === 'win' ? bet.amount * bet.odds - bet.amount : (bet.status === 'lose' ? -bet.amount : 0);
                    return (
                    <motion.div key={bet.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ type: "spring", stiffness: 300 }}>
                      <Card className="bg-text-light/10 backdrop-blur-lg border-text-light/20 text-text-light">
                        <CardHeader>
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center w-full gap-2">
                            <div><CardTitle className="text-lg text-blue-primary">{bet.event}</CardTitle></div>
                            {getStatusBadge(bet.status)}
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                            <div><p className="text-sm text-gray-400 mb-1">Monto Apostado</p><p className="font-semibold">${bet.amount.toFixed(2)}</p></div>
                            <div><p className="text-sm text-gray-400 mb-1">Momio</p><p className="font-semibold text-yellow-400">{bet.odds.toFixed(2)}</p></div>
                            <div><p className="text-sm text-gray-400 mb-1">Resultado</p><p className={`font-semibold ${profit > 0 ? 'text-highlight-green' : profit < 0 ? 'text-red-400' : 'text-gray-300'}`}>{profit > 0 ? `+ $${profit.toFixed(2)}` : profit < 0 ? `- $${Math.abs(profit).toFixed(2)}` : '$0.00'}</p></div>
                            <div><p className="text-sm text-gray-400 mb-1">Fecha</p><p className="font-semibold">{formatDate(bet.createdAt)}</p></div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )})
                )}
              </div>
            )}
          </motion.div>
        </div>

        <ProfileDialog user={client} open={showProfile} onOpenChange={setShowProfile} onUpdateUser={onUpdateUser} />
        <BankDialog open={showBank} onOpenChange={setShowBank} balance={bank.balance} onUpdateBalance={bank.updateBalance} />
        <PlaceBetDialog open={showPlaceBet} onOpenChange={setShowPlaceBet} bet={selectedBet} onPlaceBet={placeUserBet} />
      </div>
    </>
  );
}