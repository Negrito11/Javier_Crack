import React, { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { AuthForm } from '@/components/AuthForm';
import { ClientDashboard } from '@/components/ClientDashboard';
import { AdminDashboard } from '@/components/AdminDashboard';
import { Toaster } from '@/components/ui/toaster';
import { registerServiceWorker } from '@/lib/serviceWorker';

function App() {
  const { user, login, register, updateUser, logout, isLoading } = useAuth();

  useEffect(() => {
    registerServiceWorker();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-blue-base">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-primary"></div>
      </div>
    );
  }

  const renderDashboard = () => {
    if (!user) return null;
    if (user.role === 'admin') {
      return <AdminDashboard admin={user} onLogout={logout} />;
    }
    return <ClientDashboard client={user} onUpdateUser={updateUser} onLogout={logout} />;
  };

  return (
    <>
      {user ? renderDashboard() : <AuthForm onLogin={login} onRegister={register} />}
      <Toaster />
    </>
  );
}

export default App;